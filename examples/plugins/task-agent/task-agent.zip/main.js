export function activate(host) {
  host.registerTab({id:'agent',title:'任务自动化',children:[
    {id:'overview',title:'执行记录',render({container}){
      const title=document.createElement('h1');title.textContent='任务自动化';container.append(title);
      const output=document.createElement('pre');output.className='plugin-status';container.append(output);
      host.record('manual', {name:'read'}).then(async()=>output.textContent=JSON.stringify(await host.runs(),null,2)).catch(e=>{output.textContent=e.message});
    }},
    {id:'settings',title:'工具配置',render({container}){
      const label=document.createElement('p');label.textContent='填写工具可执行文件路径、参数数组和工作目录。任务上下文以 JSON 写入标准输入。';container.append(label);
      const form=document.createElement('textarea');form.rows=12;form.style.width='100%';form.value=JSON.stringify(host.config.command?host.config:{command:'',args:[],cwd:''},null,2);container.append(form);
      const save=document.createElement('button');save.className='primary';save.textContent='保存配置';save.onclick=async()=>{try{await host.saveConfig(JSON.parse(form.value));host.toast('已保存')}catch(e){host.toast(e.message)}};container.append(save);
    }}
  ]});
  host.onTrigger('task.created',async context=>{
    if(!host.config.command)throw Error('请先在任务自动化的工具配置中填写本机工具。');
    const result=await host.exec({command:host.config.command,args:host.config.args||[],cwd:host.config.cwd||'',stdin:JSON.stringify(context)});
    if(result.exitCode!==0)throw Error(result.stderr||'工具执行失败');
    let output;try{output=JSON.parse(result.stdout)}catch{output={summary:result.stdout}}
    return output;
  });
}
